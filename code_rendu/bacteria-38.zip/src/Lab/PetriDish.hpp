#ifndef PETRIDISH_HPP
#define PETRIDISH_HPP

#include "CircularBody.hpp"
#include "Bacterium.hpp"
#include "Nutriment.hpp"
#include "Swarm.hpp"
#include <vector>
#include <SFML/Graphics.hpp>
#include <Utility/Vec2d.hpp>
#include <Interface/Drawable.hpp>
#include <Interface/Updatable.hpp>

class PetriDish : public CircularBody, public Drawable, public Updatable
{
public:
    //Constructeurs et destructeurs:
    PetriDish(const Vec2d& poscenter, const double radius);
    //Constructeur
    PetriDish(const PetriDish& p) = delete;
    //Interdiction de copie d'une assiette de pétri
    ~PetriDish();
    //Destruction de l'assiette de pétri ainsi que des nutriments et bactéries qui l'habitent

    //Getters et setters:
    double getTemperature() const;
    double getGradientExponent() const;
    Swarm* getSwarmWithId(std::string id) const;

    //Surcharges d'operateurs:
    PetriDish& operator=(const PetriDish& p) = delete;
    //Interdiction d'affectation entre assiettes de pétri

    //Ajouts:
    bool addBacterium(Bacterium* bacterium);
    //Ajoute une bactérie à l'ensemble de bactéries de l'assiette
    bool addNutriment(Nutriment* nutriment);
    //Ajoute un nutriment à l'ensemble des nutriments de l'assiette
    void addSwarm (Swarm* swarm);
    //ajoute un swarm à à l'ensemble des groupes (swarms) de l'assiette

    //Autres méthodes :
    Nutriment* getNutrimentColliding(const CircularBody& body) const;
    //retourne la source de nutriment en collision avec body
    void update(sf::Time dt);
    //Fait évoluer l'assiette de pétri à chaque intervalle de temps
    void drawOn(sf::RenderTarget& targetWindow) const;
    //Représentation graphique de l'assiette de pétri et de ses contenants
    void reset();
    //Supprime nutriments et bactéries de l'assiette, réinitialise la température

    //Pour la température:
    void increaseTemperature();
    void decreaseTemperature();
    //Permet de modifier la température de la boîte de petri
    void resetTemperature();
    //Réinitialise la température à sa valeur par défaut

    //Pour le score d'une position:
    double getPositionScore(const Vec2d& p) const;
    //retourne le score associé à une position donnée
    void increaseGradientExponent();
    void decreaseGradientExponent();
    //Permet de modifier la température de la boîte de pétri
    void resetGradientExponent();
    //Réinitialise la puissance à sa valeur par défaut

private:
    std::vector<Bacterium*> bacteria_;
    std::vector<Nutriment*> nutriments_;
    std::vector<Swarm*> swarms_;
    double temperature_;
    double exponent_;

};

#endif // PETRIDISH_HPP
